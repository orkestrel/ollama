# Environment: Cursor

**1. Create/edit** — cloud environment selector → Add environment → name it `cursor`.

**2. Network access** — **Custom**, tick "Also include default list of common package
managers," and add:
    cursor.com
    *.cursor.com
    cursor.sh
    *.cursor.sh
If agent calls later fail with connection/streaming errors, Cursor has moved endpoints
— switch this environment to **Full** (tradeoff: a Full environment can reach any
domain while holding your billable key).

**3. Environment variables** (no quotes):
    CURSOR_API_KEY=<dedicated revocable key from the Cursor dashboard>
Then AFTER step 6:
    CURSOR_COMPOSER_MODEL=<exact id from `agent models`>
    CURSOR_GROK_MODEL=<exact id from `agent models`>
There is no secrets store — the key is visible to anyone who can edit this
environment. Keep it personal; keep it revocable.

**4. Setup script** — paste `cursor-setup.sh` (in this zip) into the Setup script field.

**5. Repo** — commit the `repo/` tree at your repo root (identical across all three
environment zips — commit once): `chmod +x scripts/*.sh`, commit, push. Three SessionStart hooks run in parallel each session: deps.sh (dependencies),
ollama.sh (reports no daemon here), cursor.sh (bench sensing: auth + model pins).

**6. Verify** — new session, prompt: "Run `command -v agent`, `agent status`, and
`agent models`. Do not print CURSOR_API_KEY. Report the exact Composer and Grok model
IDs." Record those IDs as the two env vars above; new sessions pick them up.

**7. Smoke test** — "Dispatch `grok` to review this repo's error handling; then
dispatch `composer` with a trivial fully-specified unit and report its worktree diff."
