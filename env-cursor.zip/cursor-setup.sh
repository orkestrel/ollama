#!/bin/bash
# ============================================================================
# CURSOR environment — SETUP SCRIPT (paste into the env's "Setup script" field)
# ----------------------------------------------------------------------------
# Runs ONCE as root on Ubuntu 24.04 before Claude Code launches; the filesystem
# is then snapshotted. Re-runs only when this script or the allowed hosts
# change, or the ~7-day cache expires. Needs network access to cursor.com.
# Per-session bench sensing lives in the repo hook scripts/cursor.sh.
# ============================================================================
set -euo pipefail

# Install under /opt, NOT /root: the session user may differ from root, and
# /root is typically unreadable to it — a symlink into /root would dangle.
export CURSOR_HOME=/opt/cursor
mkdir -p "$CURSOR_HOME"
curl -fsS https://cursor.com/install | HOME="$CURSOR_HOME" bash
chmod -R a+rX "$CURSOR_HOME"

# The CLI binary is named `agent` in current releases (`cursor-agent`
# historically). Link whichever the installer produced into the global PATH.
FOUND=""
for name in agent cursor-agent; do
  if [ -x "$CURSOR_HOME/.local/bin/$name" ]; then
    ln -sf "$CURSOR_HOME/.local/bin/$name" "/usr/local/bin/$name"
    FOUND="$name"
  fi
done
if [ -z "$FOUND" ]; then
  echo "ERROR: Cursor installer produced no agent binary in $CURSOR_HOME/.local/bin" >&2
  ls -la "$CURSOR_HOME/.local/bin" >&2 || true
  exit 1
fi

# Fail environment creation loudly if the binary doesn't run.
"$FOUND" --version

# Non-fatal auth probe; never print the key itself.
if [ -n "${CURSOR_API_KEY:-}" ]; then
  "$FOUND" status || echo "warn: agent status failed — check CURSOR_API_KEY (without printing it)" >&2
else
  echo "note: CURSOR_API_KEY not visible during setup; auth will be checked in-session."
fi

echo "Cursor environment setup complete: $FOUND"
