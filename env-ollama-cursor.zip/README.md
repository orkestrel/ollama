# Environment: Ollama + Cursor

**1. Create/edit** — cloud environment selector → Add environment → name it
`ollama-cursor`.

**2. Network access** — **Custom**, tick "Also include default list of common package
managers," and add the union:
    ollama.com
    *.ollama.com
    registry.ollama.ai
    cursor.com
    *.cursor.com
    cursor.sh
    *.cursor.sh
(Same Full-fallback note as the Cursor environment if agent streaming ever breaks.)

**3. Environment variables** (no quotes):
    OLLAMA_MODELS=/opt/ollama/models
    OLLAMA_HOST=127.0.0.1:11434
    CURSOR_API_KEY=<dedicated revocable key>
Then after the first verify session:
    CURSOR_COMPOSER_MODEL=<exact id from `agent models`>
    CURSOR_GROK_MODEL=<exact id from `agent models`>

**4. Setup script** — paste `ollama-cursor-setup.sh` (in this zip) into the Setup
script field. The ~1.9 GB model pull dominates its runtime.

**5. Repo** — commit the `repo/` tree at your repo root (identical across all three
environment zips — commit once): `chmod +x scripts/*.sh`, commit, push. Three SessionStart hooks run
in parallel each session: deps.sh, ollama.sh (daemon + self-heal), cursor.sh (bench
sensing).

**6. Verify** — new session, prompt: "1) curl http://127.0.0.1:11434/api/tags and
confirm the model. 2) Run `command -v agent`, `agent status`, `agent models` — do not
print CURSOR_API_KEY — and report the exact Composer and Grok IDs. 3) Report the last
lines of /tmp/ollama.log." Record the two model IDs as env vars.
