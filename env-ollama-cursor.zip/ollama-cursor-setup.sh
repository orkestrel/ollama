#!/bin/bash
# ============================================================================
# OLLAMA + CURSOR environment — SETUP SCRIPT (paste into "Setup script" field)
# ----------------------------------------------------------------------------
# Composition of ollama-setup.sh and cursor.sh — one environment with both the
# local-model daemon and the external bench. Runs ONCE as root; snapshot rules
# as usual. The model pull (~1.9 GB) dominates runtime; still inside the ~5 min
# cache budget. Per-session pieces: repo hooks scripts/ollama.sh, scripts/deps.sh, scripts/cursor.sh.
# ============================================================================
set -euo pipefail

# ----------------------------- OLLAMA ---------------------------------------
export OLLAMA_MODELS=/opt/ollama/models
export OLLAMA_HOST=127.0.0.1:11434
mkdir -p "$OLLAMA_MODELS"
chmod -R 0777 /opt/ollama

apt-get update
apt-get install -y zstd   # required by current Ollama release archives

curl -fsSL https://ollama.com/install.sh | sh
systemctl stop ollama 2>/dev/null || true
systemctl disable ollama 2>/dev/null || true

nohup ollama serve >/tmp/ollama-setup.log 2>&1 &
SERVE_PID=$!
for i in $(seq 1 30); do
  curl -sf "http://${OLLAMA_HOST}/api/tags" >/dev/null 2>&1 && break
  sleep 1
done
ollama pull qwen3.5:2b-q4_K_M
kill "$SERVE_PID" 2>/dev/null || true

# ----------------------------- CURSOR ---------------------------------------
export CURSOR_HOME=/opt/cursor
mkdir -p "$CURSOR_HOME"
curl -fsS https://cursor.com/install | HOME="$CURSOR_HOME" bash
chmod -R a+rX "$CURSOR_HOME"

FOUND=""
for name in agent cursor-agent; do
  if [ -x "$CURSOR_HOME/.local/bin/$name" ]; then
    ln -sf "$CURSOR_HOME/.local/bin/$name" "/usr/local/bin/$name"
    FOUND="$name"
  fi
done
if [ -z "$FOUND" ]; then
  echo "ERROR: Cursor installer produced no agent binary in $CURSOR_HOME/.local/bin" >&2
  exit 1
fi
"$FOUND" --version
if [ -n "${CURSOR_API_KEY:-}" ]; then
  "$FOUND" status || echo "warn: agent status failed — check CURSOR_API_KEY (without printing it)" >&2
fi

echo "Ollama + Cursor environment setup complete."
