# Placement — orchestration repo files

This repo/ tree is IDENTICAL across all three environment zips — commit it once and it
serves every environment. Unzip repo/ contents at the repo root, then:
    chmod +x scripts/*.sh
    git add -A && git commit -m "Split session hooks; Cursor delegation; orkestrel specialist" && git push

**How per-environment behavior works:** `.claude/settings.json` registers all three
SessionStart hooks unconditionally — it cannot branch, because the repo (and this file
with it) is shared by every environment. Each hook senses its own environment instead:
`ollama.sh` and `cursor.sh` exit quietly where their binary isn't installed, using the
binary itself as ground truth. Hooks run in parallel, and their stdout is injected into
Claude's context — so the one-line announcements ("Ollama ready", "bench lit/dark",
"deps installed") are how the orchestrator learns what this environment offers.

| File | Status |
| --- | --- |
| CLAUDE.md | UPDATED — bench-first + fallback pairs, why-routing-not-frontmatter, `orkestrel` integration |
| AGENTS.md | UPDATED — external delegates bound identically |
| SCAFFOLD.md | UPDATED — §13.4 Delegated scaffold (Composer fast-path) |
| .claude/settings.json | UPDATED — three parallel SessionStart hooks (deps, ollama, cursor) with explicit timeouts |
| scripts/deps.sh | NEW — project dependencies only; npm noise to /tmp/deps.log, one context line |
| scripts/ollama.sh | UPDATED — Ollama only: daemon + readiness + AMX/XTILE self-heal (preserved verbatim) |
| scripts/cursor.sh | NEW — Cursor bench sensing only: binary, auth, model pins; announces lit/dark |
| .claude/agents/orkestrel.md | NEW — @orkestrel ecosystem specialist & coordinator |
| .claude/agents/composer.md · grok.md | UPDATED — bench-dark guard with named fallback route |
| .claude/agents/builder.md · reviewer.md · planner.md | UPDATED — routing boundaries, external-input audit, unit routes |
| .claude/agents/scout.md · researcher.md · checker.md · verifier.md | unchanged (byte-identical to originals) |

Setup scripts are NOT repo files — each environment zip carries its own at the zip root
(`ollama-setup.sh`, `cursor-setup.sh`, or `ollama-cursor-setup.sh`); paste it into that
cloud environment's Setup script field. guide.md remains deliberately untouched
(package API contract per AGENTS §22).
