# Environment: Ollama

**1. Create/edit** — cloud environment selector → Add environment → name it `ollama`.

**2. Network access** — **Custom**, tick "Also include default list of common package
managers," and add:
    ollama.com
    *.ollama.com
    registry.ollama.ai

**3. Environment variables** (no quotes — quotes become part of the value):
    OLLAMA_MODELS=/opt/ollama/models
    OLLAMA_HOST=127.0.0.1:11434

**4. Setup script** — paste `ollama-setup.sh` (in this zip) into the Setup script
field. Save. Editing the script or the domain list rebuilds the environment cache on
the next session; editing env vars does not.

**5. Repo** — commit the `repo/` tree at your repo root (identical across all three
environment zips — commit once): `chmod +x scripts/*.sh`, commit, push. Three SessionStart hooks run in parallel each session: deps.sh (dependencies),
ollama.sh (daemon + AMX self-heal), cursor.sh (bench sensing — reports dark here).

**6. Verify** — new session, prompt: "curl http://127.0.0.1:11434/api/tags and confirm
the model is listed; then report the last lines of /tmp/ollama.log."

In this environment the Cursor bench is dark: `composer`/`grok` dispatchers report it
and the orchestrator falls back to `builder`/`reviewer` automatically per CLAUDE.md.
