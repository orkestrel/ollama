#!/bin/bash
# ============================================================================
# OLLAMA environment — SETUP SCRIPT (paste into the env's "Setup script" field)
# ----------------------------------------------------------------------------
# Runs ONCE as root on Ubuntu 24.04 before Claude Code launches; the filesystem
# is then snapshotted (files, not processes). Re-runs only when this script or
# the allowed hosts change, or the ~7-day cache expires. Keep under ~5 minutes.
# Per-session pieces live in the repo hooks: scripts/ollama.sh (daemon + self-heal),
# scripts/deps.sh (dependencies), scripts/cursor.sh (bench sensing).
# ============================================================================
set -e

# Fixed, world-readable install location: this runs as root, the session may not.
export OLLAMA_MODELS=/opt/ollama/models
export OLLAMA_HOST=127.0.0.1:11434
mkdir -p "$OLLAMA_MODELS"
chmod -R 0777 /opt/ollama

# zstd — REQUIRED: current Ollama releases ship zstd archives and abort without it.
apt-get update
apt-get install -y zstd

# (Optional) Node 24 — cloud images ship 20/21/22 via nvm. Uncomment if required:
# export NVM_DIR="$HOME/.nvm"; . "$NVM_DIR/nvm.sh"
# nvm install 24 && nvm alias default 24

# Ollama runtime.
curl -fsSL https://ollama.com/install.sh | sh

# Stop/disable any installer-registered systemd unit: left enabled it would bind
# :11434 as the `ollama` user with its own models path, hiding the model below.
# The repo hook starts the daemon per session instead. Harmless without systemd.
systemctl stop ollama 2>/dev/null || true
systemctl disable ollama 2>/dev/null || true

# Pre-pull the model so its blobs land in the snapshot. `ollama pull` needs a
# running server, so start one just for the pull, then stop it.
nohup ollama serve >/tmp/ollama-setup.log 2>&1 &
SERVE_PID=$!
for i in $(seq 1 30); do
  curl -sf "http://${OLLAMA_HOST}/api/tags" >/dev/null 2>&1 && break
  sleep 1
done
ollama pull qwen3.5:2b-q4_K_M
kill "$SERVE_PID" 2>/dev/null || true

echo "Ollama environment setup complete."
